exports.getStatus = (req,res)=>{
    res.json({ status:"OK", message:"Reportes funcionando" });
};
